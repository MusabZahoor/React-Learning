const Student = ({ name, age, course }) => {
  return (
    <>
      <p>
        My name is {name} and my age is {age} and i'm learning {course}
      </p>
    </>
  );
};
export default Student;
