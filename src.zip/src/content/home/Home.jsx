import "./Home.css";
const Home = () => {
  return (
    <>
      <div className="home">This is Home Page</div>
    </>
  );
};
export default Home;
