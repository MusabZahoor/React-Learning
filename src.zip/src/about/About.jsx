import "./About.css";
const About = () => {
  return (
    <>
      <div className="about">This is About Page</div>
    </>
  );
};
export default About;
