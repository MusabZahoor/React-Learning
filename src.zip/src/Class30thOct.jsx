const Class30thOct = () => {
  let name = "abc";
  return (
    <>
      <h1>Hello {name}</h1>
    </>
  );
};
export default Class30thOct;
