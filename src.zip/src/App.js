import AppShop from "./shopAssignment/AppShop";

function App() {
  return <AppShop />;
}

export default App;
