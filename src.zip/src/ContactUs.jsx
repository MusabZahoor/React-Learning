import React from 'react'

const ContactUs = () => {
  return (
    <div>
      <h1>This is a Contact us Page</h1>
    </div>
  )
}

export default ContactUs
