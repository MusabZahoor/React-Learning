import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ShopProductsProvider } from "./ShopProductsContext";
import ShopHeader from "./ShopHeader";
import WomenShop from "./WomenShop";
import MenShop from "./MenShop";
import KidsShop from "./KidsShop";
import "./AppShop.css";

const AppShop = () => {
  return (
    <ShopProductsProvider>
      <Router>
        <ShopHeader />
        <Routes>
          <Route path="/" element={<Navigate to="/women-shop" />} />
          <Route path="/women-shop" element={<WomenShop />} />
          <Route path="/men-shop" element={<MenShop />} />
          <Route path="/kids-shop" element={<KidsShop />} />
        </Routes>
      </Router>
    </ShopProductsProvider>
  );
};

export default AppShop;
