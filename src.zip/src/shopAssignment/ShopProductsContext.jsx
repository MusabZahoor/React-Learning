import React, { createContext } from "react";

export const ShopProductsContext = createContext();

export const ShopProductsProvider = ({ children }) => {
  const womenProducts = [
    { id: 1, name: "Summer Dress", img: "https://via.placeholder.com/200x200?text=Summer+Dress", salePrice: 45, originalPrice: 70 },
    { id: 2, name: "Heels", img: "https://via.placeholder.com/200x200?text=Heels", salePrice: 60, originalPrice: 90 },
  ];

  const menProducts = [
    { id: 1, name: "Denim Jacket", img: "https://via.placeholder.com/200x200?text=Denim+Jacket", salePrice: 85, originalPrice: 120 },
    { id: 2, name: "Sneakers", img: "https://via.placeholder.com/200x200?text=Sneakers", salePrice: 65, originalPrice: 100 },
  ];

  const kidsProducts = [
    { id: 1, name: "Cartoon Hoodie", img: "https://via.placeholder.com/200x200?text=Cartoon+Hoodie", salePrice: 30, originalPrice: 45 },
    { id: 2, name: "Shorts", img: "https://via.placeholder.com/200x200?text=Shorts", salePrice: 20, originalPrice: 35 },
  ];

  return (
    <ShopProductsContext.Provider value={{ womenProducts, menProducts, kidsProducts }}>
      {children}
    </ShopProductsContext.Provider>
  );
};
